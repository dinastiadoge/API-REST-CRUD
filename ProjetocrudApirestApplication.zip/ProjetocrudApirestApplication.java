package com.projeto.crud.restapi.projetocrudapirest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetocrudApirestApplication {

    public static void main(String[] args) {
        System.out.println("projeto subindo");
        SpringApplication.run(ProjetocrudApirestApplication.class, args);
        System.out.println("projeto no servidor");
    }

}
